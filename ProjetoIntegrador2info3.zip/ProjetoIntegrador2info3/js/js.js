
$(document).ready(function(){
$('.dorp').dropdown();
$('.ui.checkbox').checkbox();
$('#example4').progress('increment');
$('.desce').dropdown();
$('.special.cards .image').dimmer({on: 'hover'});
$('.ui.rating').rating();
$('.ui.rating.interacao').rating();
});