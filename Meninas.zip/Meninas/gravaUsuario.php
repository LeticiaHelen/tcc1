<?php
$infos=[];
$infos=$_POST;
$abrir=fopen('usuarios.csv', 'a+');
$arquivo=file('usuarios.csv');
$virgula=";";
$prim="\n".$infos['primeiroNome'];
$prim.=$virgula.$infos['ultimoNome'];
$prim.=$virgula.$infos['idade'];
$prim.=$virgula.$infos['email'];
$prim.=$virgula.$infos['nomeusuario'];
$prim.=$virgula.$infos['password'].$virgula;
fwrite($abrir, $prim);
fclose($abrir);
?>
<meta http-equiv="refresh" content="1;URL='login.php" />
