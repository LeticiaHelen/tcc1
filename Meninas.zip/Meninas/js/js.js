
$(document).ready(function(){
$('.dorp').dropdown();
$('.ui.checkbox').checkbox();
$('#example4').progress('increment');
$('.desce').dropdown();

});