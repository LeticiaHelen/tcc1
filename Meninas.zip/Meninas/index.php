<?php 
include("cabecalho.php");
include 'slider2.php';
?>
<h1 class="centra black">JOGOS</h1>
<div class="ui grid center aligned page grid ">
  <?php
  $lista=listaResenhas();
  $ver=rand(16,16);
  foreach ($lista as $dados) {
    if ($dados['cod']<=$ver) {
      echo('
      <div class="four wide column ">
      <a href="detalhaResenha.php?cod='.$dados['cod'].'">
      <div class="ui card">
      <div class="ui  image">
      <img src="imagens/'.$dados['imagem1'].'" class="visible content">
      </div>
      <div class="content">
      <a class="header" href="detalhaResenha.php?cod='.$dados['cod'].'">'.$dados['nome'].'</a>
      <div class="meta">
      <span class="date">'.$dados['info'].'</span>
      </div>
      </div>
      </div>
      </a>
      </div>
      '); 
    }
  }
  ?>
</div> 
</div>
<?php
include "rodape.php";
?>


