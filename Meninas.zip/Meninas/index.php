<?php 
include("cabecalho.php");
//include 'slider2.php';
?>
<div class="marginTop"></div>
<h1 class="centra black">JOGOS</h1>
<div class="ui grid center aligned page grid ">
  <?php
  $lista=listaResenhas();
  $ver=rand(26,26);
  foreach ($lista as $dados) {
    if ($dados['cod']<=$ver) {
      echo('
       <div class="ui cards">
       <div class="udm_free_ispell_data(agent) card">
       <div class="image">
       <img src="imagens/'.$dados['imagem1'].'">
       </div>
       <div class="extra">
       <a class="header"  href="detalhaResenha.php?cod='.$dados['cod'].'">'.$dados['nome'].'</a>
       <div class="meta">
       <span class="date">'.$dados['info'].'</span>
       </div>
       </div>
       </div>
       </div>
       '); 
    }
  }
  ?>
</div>
<?php
include "rodape.php";
?>


<!--<img src="imagens/'.$dados['imagem1'].'">
<i class="'.$dados['icone'].' icon"></i>
'.$dados['categoria'].'
<a class="header"  href="detalhaResenha.php?cod='.$dados['cod'].'">'.$dados['nome'].'</a>       
<div class="meta">
  <span class="date">'.$dados['info'].'</span>
</div> !-->