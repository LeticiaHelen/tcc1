<?php
error_reporting(0);
session_start();
function listaResenhas(){
	$resenha= array();

	$dados= file("dados.csv");

	foreach ($dados as $posicao => $linha) {
		if ($posicao !=0) {
			$colunas= explode(";",$linha);
			$resenha['cod'] =$colunas[0];
			$resenha['nome'] =$colunas[1];
			$resenha['imagem1'] =$colunas[2];
			$resenha['imagem2'] =$colunas[3];
			$resenha['info'] =$colunas[4];
			$resenha['categoria'] =$colunas[5];
			$resenha['icone'] =$colunas[6];
			$resenha['resenha'] =$colunas[7];
			$resenhas[]=$resenha;
		}
	}
	return $resenhas;
}

function buscaResenha($codigo){
	$resenha= array();
	$dados= file("dados.csv");
	foreach ($dados as $linha) {
		$colunas= explode(";",$linha);
		if($colunas[0]==$codigo){
			$resenha['cod'] =$colunas[0];
			$resenha['nome'] =$colunas[1];
			$resenha['imagem1'] =$colunas[2];
			$resenha['imagem2'] =$colunas[3];
			$resenha['info'] =$colunas[4];
			$resenha['categoria'] =$colunas[5];
			$resenha['icone'] =$colunas[6];
			$resenha['resenha'] =$colunas[7];
			$resenha['autor']=$colunas[8];
		}
	}
	
	return $resenha;
}

function listaCategoria(){
	$categoria= array();
	$dados= file("categorias.csv");
	foreach ($dados as $posicao => $linha) {
		if ($posicao !=0) {
			$colunas= explode(";",$linha);
			$categoria['cod'] =$colunas[0];
			$categoria['categoria'] =$colunas[1];
			$categorias[]=$categoria;
		}
	}
	return $categorias;
}

function buscaCategoria($codigo){
	$categoria=array();
	$dados= file("dados.csv");
	foreach ($dados as $linha) {
		$dados=explode(";",$linha);
		if($dados[5]==$codigo){
			$categoria['cod'] =$dados[0];
			$categoria['nome'] =$dados[1];
			$categoria['imagem1'] =$dados[2];
			$categoria['imagem2'] =$dados[3];
			$categoria['info'] =$dados[4];
			$categoria['categoria'] =$dados[5];
			$categoria['icone'] =$dados[6];
			$categoria['resenha'] =$dados[7];
			$categorias[]=$categoria;
		}
	}
	return $categorias;
}

function testaUsuario($user,$senha){
	$dados= file("usuarios.csv");
	$todosDados=[];
	foreach ($dados as $linha) {
		$dados=explode(";",$linha);
		$todosDados[]=$dados;
	}
	$cont=0;
	foreach ($todosDados as $key) {
		if ($key[4]==$user) {
			$cont++;
			$guarda=$key[5];
			$_SESSION['nome']=$key[4];
		}
	}
	if($cont==0){
		$retorna=0;
		return $retorna;
	}elseif($guarda==$senha) {
		$_SESSION['logado']=1;
		$retorna=1;
		return $retorna;
	}else{
		$retorna=0;
		return $retorna;
	}	
} 