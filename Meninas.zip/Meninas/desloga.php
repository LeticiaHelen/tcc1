<?php
session_start();
?>
<h1><center>Carregando...</h1></center>
<br>
<center><h2>Tchau  
<?php 
echo $_SESSION['nome']."</h2></center> ";
$_SESSION['logado']=0;
?>
<meta http-equiv="refresh" content="2; url='index.php">