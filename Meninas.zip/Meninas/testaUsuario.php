<?php
include "funcoes.php";
$user=$_POST['user'];
$senha=$_POST['senha'];
$testa=testaUsuario($user,$senha);
if(isset($_SESSION['nome'])){
	$nome=$_SESSION['nome'];
}
if($testa==0){
	$teste=0;
}elseif($testa==1) {
	$teste=1;
}else{
	$teste=0;
}
if($teste==1){
	echo "
	<center>
	<h1>Logando</h1>
	<br>
	<br>
	<h1>Seja Bem-Vindo  ".$nome."</h1>
	</ssscenter>
	";
	echo "<meta http-equiv='refresh' content='3; url=index.php?testa=1'>";
}else{
	echo "<center><h1>Invalid data</h1></center>";
	echo "<meta http-equiv='refresh' content='2; url=login.php'>";
}