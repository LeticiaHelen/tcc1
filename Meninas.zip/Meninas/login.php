<?php
include 'cabecalho.php';
?>
<div class="topper">.</div>
<div class="ui two column middle aligned very relaxed stackable grid center aligned page grid">
  <div class="column">
    <form method="post" action="testaUsuario.php">    
      <div class="ui form" >
        <div class="field">
          <label>Nome de Usuario</label>
          <div class="ui left icon input">
            <input type="text" placeholder="Nome de Usuario" name="user">
            <i class="user outline circle icon"></i>
          </div>
        </div>
        <div class="field">
          <label>Senha</label>
          <div class="ui left icon input">
            <input type="password" placeholder="Senha" name="senha">
            <i class="lock icon"></i>
          </div>
        </div>
        <button class="ui button" type="submit">Logar</button>
      </div>
    </form>
  </div>
  <div class="center aligned column">
    <a href="registro.php">
      <div class="ui big blue labeled icon button">
        <i class="edit outline icon"></i>
        Registre-se
      </div>
    </div>
  </a>
</div>
<div class="rodape1"></div>
<?php
include 'rodape.php';