<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="semantic/semantic.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.1/semantic.min.css"></script>
	<link rel="shortcut icon" href="imagens/logopreto.png" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="semantic/semantic.min.js"></script>
	<script type="text/javascript" src="js/js.js"></script>
	<link rel="stylesheet" type="text/css" href="css/principal.css">
	<title>Read.</title>
	<meta charset="UTF-8">
	<style type="text/css">
    .item{
      width: 10%;
    }
    .espaco_menu{
      width: 15%;
      color: white;
    }
  </style>
</head>
<body class="cor_menu2">
	<?php
	include "funcoes.php";
	?>
	<div class="ui menu cor_menu">
		<a class="item tit" href="index.php">
			<div>
				<h3 class="cor_letra">Read.</h3>
			</div>
		</a>
		<a class="item" href="index.php">
			<h5 class="cor_letra">Home</h5>
		</a>
		<div class="ui pointing dropdown link item white dorp">
			<div class="aqui">
				<span class="text cor_letra">Categorias</span>
				<i class="dropdown icon inverted"></i>
			</div>
			<div class="menu">
				<?php

				$outraLista=listaCategoria();
				foreach ($outraLista as $categoria) {
					echo '<a class="item" href="detalhaCategoria.php?cod2='.$categoria["cod"].'">'.$categoria["categoria"].'</a>';
				}
				?>
			</div>
		</div>
		<?php
		if(isset($_SESSION['logado'])){
			if($_SESSION['logado']==1){
				?>
				<a class="item" href="minhasResenhas.php">
					<h5 class="cor_letra">Suas Resenhas</h5>
				</a>
				
				<?php
			}
		}
		if(isset($_SESSION['logado'])){
			if($_SESSION['logado']==1){
				?>
				<a class="item cor_letra" href="cadastrarResenha.php">
					<h5 class="cor_letra">Cadastra Resenha</h5>
				</a>
				<div class="ui category search item right">
					<div class="ui icon input">
						<input class="prompt right" type="text" placeholder="Seach games">
						<i class="search icon"></i>
					</div>
					<div class="results"></div>
				</div>
				<a class='item cor_letra' href="desloga.php">
					<h5 class="cor_letra">Deslogar</h5>
				</a>
				<?php
			}else{
				?>
				<a class="item cor_letra" href="cadastrarResenha.php">
					<h5 class="cor_letra">Cadastra Resenha</h5>
				</a>
				<div class="ui category search item right">
					<div class="ui icon input">
						<input class="prompt right" type="text" placeholder="Seach games">
						<i class="search icon"></i>
					</div>
					<div class="results"></div>
				</div>
				<a class="item right " href="login.php">
					<h5 class="cor_letra">Logar</h5>
				</a>
			
				<?php
			}

		}else{
			echo"<a class='item right cor_letra' href='login.php'>Login</a>";
		}
		?>
	</div>
</div>
</div>
