<br>
<br>
<div class="ui inverted vertical footer segment rodape">
  <div class="ui center aligned container">
    <div class="ui stackable inverted divided grid">
      <div class="three wide column centered">
        <h4 class="ui inverted header">Developers</h4>
        <div class="ui inverted link list">
          <a class="item">Clara Souza de Jesus</a>
          <a class="item">Felipe Passig</a>
          <a class="item">Leticia Helen de Sousa</a>
        </div>
      </div>
      <div class="seven wide column">
        <h4 class="ui inverted header">Read.</h4>
        <p>Alguma coisa</p>
      </div>
    </div>
    <br>
    <br>
    <a href="#" target="_blank">
      <button class="blue ui facebook button">
        <i class="facebook icon"></i>
        Facebook
      </button>
    </a>
    <a href="#" target="_blank">
      <button class="blue ui twitter button">
        <i class="twitter icon"></i>
        Twitter
      </button>
    </a>
    <a href="#" target="_blank">
      <button class=" blue ui instagram button">
        <i class="instagram icon"></i>
        Instagram
      </button>
    </a>
    <br>
    <div class="ui horizontal inverted small divided link list">
      <a class="item" href="#">Localização</a>
      <a class="item" href="#">Contato</a>
      <a class="item" href="#">Termos</a>
      <a class="item" href="#">Politica de privacidade</a>
    </div>
  </div>
</div>
</body>
</html>