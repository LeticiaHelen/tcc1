<?php
include "cabecalho.php";
$codigo=$_GET['cod'];
$jogo=buscaResenha($codigo);
?>
<div class="gridDupla">
	<div class="imagem">
        <?php
        echo'
        <div class="ui four column grid">
        <div class="column">
        <div class="ui fluid image">
        <div class="ui black ribbon label">
        <a class="header"><i class="'.$jogo["icone"].' outline icon black large"></i> '.$jogo["categoria"].'</a>
        </div>
        <div class="fotoResenha">
        <img src="imagens/'.$jogo["imagem1"].'">
        </div>
        </div>
        </div>
        <div class="resenha">
        ';
        if (isset($_SESSION['logado'])) {
          if ($_SESSION['nome']=='admin' and $_SESSION['logado']==1) {
            echo'
            <div class="ui left icon top left pointing dropdown desce">
            <i class="sun outline icon"></i>
            <div class="menu">
            <div class="header">Opções</div>
            <div class="item red" >Excluir</div>
            <div class="item"  >Editar</div>
            </div>
            </div>';
        }
    }
    echo'
    <h2 class="nomeResenha">'.$jogo['nome'].'</h2>
    <div class="texto">
    '.$jogo["resenha"].'
    </div>
    <br>
    <h4 class="autor">Autor: '.$jogo["autor"].'</h4>
    </div>
    </div>
    </div>
    </div>
   '
    ;?>
    <section class="lateral">....</section>
    <section class="coments">
    <div class="ui comments">
  <h3 class="ui dividing header">Comments</h3>
  <div class="comment">
    <a class="avatar">
      <img src="/images/avatar/small/matt.jpg">
    </a>
    <div class="content">
      <a class="author">Matt</a>
      <div class="metadata">
        <span class="date">Today at 5:42PM</span>
      </div>
      <div class="text">
        How artistic!
      </div>
      <div class="actions">
        <a class="reply">Reply</a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <img src="/images/avatar/small/elliot.jpg">
    </a>
    <div class="content">
      <a class="author">Elliot Fu</a>
      <div class="metadata">
        <span class="date">Yesterday at 12:30AM</span>
      </div>
      <div class="text">
        <p>This has been very useful for my research. Thanks as well!</p>
      </div>
      <div class="actions">
        <a class="reply">Reply</a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <img src="/images/avatar/small/jenny.jpg">
        </a>
        <div class="content">
          <a class="author">Jenny Hess</a>
          <div class="metadata">
            <span class="date">Just now</span>
          </div>
          <div class="text">
            Elliot you are always so right :)
          </div>
          <div class="actions">
            <a class="reply">Reply</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <img src="/images/avatar/small/joe.jpg">
    </a>
    <div class="content">
      <a class="author">Joe Henderson</a>
      <div class="metadata">
        <span class="date">5 days ago</span>
      </div>
      <div class="text">
        Dude, this is awesome. Thanks so much
      </div>
      <div class="actions">
        <a class="reply">Reply</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea class="textarea" placeholder="Comente aqui"></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Add Reply
    </div>
  </form>
</div>
</section>
<section class="lateral2">....</section>

    <?php
    //include ("rodape.php");
    ?>
    


