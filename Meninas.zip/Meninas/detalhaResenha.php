<?php
include "cabecalho.php";
$codigo=$_GET['cod'];
$jogo=buscaResenha($codigo);
?>
<div class="gridDupla">
	<div class="imagem">
        <?php
        echo'
        <div class="ui four column grid">
        <div class="column">
        <div class="ui fluid image">
        <div class="ui white ribbon label">
        <a class="header"><i class="'.$jogo["icone"].' outline icon black large"></i> '.$jogo["categoria"].'</a>
        </div>
        <div class="fotoResenha">
        <img src="imagens/'.$jogo["imagem1"].'">
        </div>
        </div>
        </div>
        <div class="resenha">
        ';
        if (isset($_SESSION['logado'])) {
          if ($_SESSION['nome']=='admin' and $_SESSION['logado']==1) {
            echo'
            <div class="ui icon top left pointing dropdown flutua">
            <i class="wrench icon"></i>
            <div class="menu">
            <div class="header">Settings</div>
            <div class="item red" ><a href="excluir.php?imagem='.$codigo.'">Delete</a></div>
            <div class="item"  >To Edit</div>
            </div>
            </div>';
        }
    }
    echo'
    <h1 class="nomeResenha">'.$jogo['nome'].'</h1>
    <div class="texto">
    <h3>'.$jogo["resenha"].'</h3>
    </div>
    <br>
    <h4 class="autor">Autor: '.$jogo["autor"].'</h4>
    </div>
    </div>
    </div>
    </div>
    <div class="rodaresenha"></div>'
    ;
    include ("rodape.php");
    ?>


